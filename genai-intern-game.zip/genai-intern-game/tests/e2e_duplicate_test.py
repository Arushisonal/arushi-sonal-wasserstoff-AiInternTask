# tests/e2e_duplicate_test.py

import pytest
from httpx import AsyncClient
from backend.main import app

@pytest.mark.asyncio
async def test_duplicate_guess():
    async with AsyncClient(app=app, base_url="http://test") as client:
        start = await client.post("/start")
        session_id = start.json()["session_id"]

        # First valid guess
        first = await client.post("/guess", json={"session_id": session_id, "guess": "Fire"})
        assert "✅" in first.json()["message"]

        # Duplicate guess
        second = await client.post("/guess", json={"session_id": session_id, "guess": "Fire"})
        assert "already guessed" in second.json()["message"]
