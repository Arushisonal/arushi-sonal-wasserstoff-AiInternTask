let sessionId = "";
const baseURL = "http://127.0.0.1:8000/api";  // Ensure your FastAPI is running

let score = 0;

async function startGame() {
    const res = await fetch(`${baseURL}/start`, { method: "POST" });
    const data = await res.json();
    sessionId = data.session_id;
    score = 0;
    document.getElementById("scoreBoard").innerText = `Score: ${score}`;
    document.getElementById("output").innerHTML = `🎮 <b>Game Started!</b><br>Seed word: <b>${data.seed_word}</b>`;
}

async function submitGuess() {
    const guess = document.getElementById("guessInput").value.trim();
    if (!guess) return;

    const res = await fetch(`${baseURL}/guess`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ session_id: sessionId, guess })
    });

    const data = await res.json();

    if (data.message?.startsWith("✅")) {
        score++;
        document.getElementById("scoreBoard").innerText = `Score: ${score} 🎉`;
        document.getElementById("output").innerHTML =
            `<span class="confetti">✅</span> <b>${data.message}</b><br><br>
             <b>Last 5 guesses:</b> ${data.last_five_guesses.join(", ")}`;
    } else {
        document.getElementById("output").innerHTML =
            `<span style="color: red;">❌ Game Over</span><br><b>${data.message}</b><br>Your final score: ${data.final_score}`;
        document.getElementById("scoreBoard").innerText = `Final Score: ${data.final_score}`;
    }
}

async function getHistory() {
    const res = await fetch(`${baseURL}/history?session_id=${sessionId}`);
    const data = await res.json();
    document.getElementById("output").innerHTML =
        `<b>📜 Last 5 Guesses:</b><br>${data.history.join(", ")}`;
}
