# backend/core/game_logic.py

class GuessNode:
    def __init__(self, word):
        self.word = word
        self.next = None

class GameLinkedList:
    def __init__(self):
        self.head = None
        self.words_set = set()

    def add_guess(self, word):
        if word in self.words_set:
            return False  # Word already guessed before = Game Over
        new_node = GuessNode(word)
        if not self.head:
            self.head = new_node
        else:
            current = self.head
            while current.next:
                current = current.next
            current.next = new_node
        self.words_set.add(word)
        return True  # Guess accepted

    def get_last_five_guesses(self):
        guesses = []
        current = self.head
        while current:
            guesses.append(current.word)
            current = current.next
        return guesses[-5:]  # Return last 5 guesses
