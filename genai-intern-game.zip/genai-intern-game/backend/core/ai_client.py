import openai
from backend.core.cache import cache

class AIClient:
    def __init__(self):
        # Hardcode your API key here during development
        openai.api_key = "XSS"  # ⚠️ Replace with your actual key temporarily

    async def validate_guess(self, last_word: str, guess: str) -> bool:
        # Check cache first
        cached_verdict = await cache.get_cached_verdict(last_word, guess)
        if cached_verdict is not None:
            return cached_verdict.lower() == "yes"

        prompt = (
            f"In a creative game where users play word battles, "
            f"determine if the word '{guess}' beats '{last_word}'. "
            f"Respond only with 'Yes' or 'No'."
        )

        try:
            response = openai.ChatCompletion.create(
                model="gpt-3.5-turbo",
                messages=[{"role": "user", "content": prompt}],
                temperature=0.7,
            )
            verdict = response.choices[0].message["content"].strip()

            # Cache the verdict
            await cache.cache_guess_verdict(last_word, guess, verdict)

            return verdict.lower() == "yes"

        except Exception as e:
            print("OpenAI Error:", e)
            return False
