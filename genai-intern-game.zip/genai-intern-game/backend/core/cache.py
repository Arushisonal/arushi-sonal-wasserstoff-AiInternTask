import redis.asyncio as aioredis
import hashlib

class Cache:
    def __init__(self):
        self.redis = None
        # Hardcoded Redis settings
        self.REDIS_HOST = "localhost"  # Replace with your Redis server host
        self.REDIS_PORT = 6379  # Default Redis port
        self.REDIS_DB = 0  # Default Redis DB (0)

    async def connect(self):
        """Connect to Redis."""
        self.redis = aioredis.from_url(f"redis://{self.REDIS_HOST}:{self.REDIS_PORT}", db=self.REDIS_DB)

    async def close(self):
        """Close Redis connection."""
        if self.redis:
            await self.redis.close()

    async def get(self, key: str):
        """Get cached value by key."""
        return await self.redis.get(key, encoding='utf-8')

    async def set(self, key: str, value: str, ttl: int = 3600):
        """Set a cache value with optional TTL."""
        await self.redis.setex(key, ttl, value)

    async def cache_guess_verdict(self, last_word: str, guess: str, verdict: str):
        """Cache the verdict for a pair of (last_word, guess)."""
        cache_key = self.generate_cache_key(last_word, guess)
        await self.set(cache_key, verdict)

    async def get_cached_verdict(self, last_word: str, guess: str):
        """Get the cached verdict for a pair of (last_word, guess)."""
        cache_key = self.generate_cache_key(last_word, guess)
        return await self.get(cache_key)

    def generate_cache_key(self, last_word: str, guess: str) -> str:
        """Generate a unique cache key."""
        key = f"{last_word}:{guess}"
        return hashlib.sha256(key.encode('utf-8')).hexdigest()

# Instantiate cache object
cache = Cache()
