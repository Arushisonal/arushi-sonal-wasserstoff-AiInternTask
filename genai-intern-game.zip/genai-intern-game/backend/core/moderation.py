# backend/core/moderation.py

banned_words = {
    "badword1", "badword2", "stupid", "idiot", "fool"  # Add your own list
}

def contains_profanity(word: str) -> bool:
    """
    Check if a word contains any banned/profane words.
    This is a simple example and should be replaced with a better filter if needed.
    """
    cleaned = word.lower().strip()
    return cleaned in banned_words
