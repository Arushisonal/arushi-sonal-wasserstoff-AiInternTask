# backend/db/models.py

from sqlalchemy import Column, Integer, String, ForeignKey
from sqlalchemy.orm import relationship
from sqlalchemy.ext.declarative import declarative_base

Base = declarative_base()

class GameSession(Base):
    __tablename__ = "game_sessions"

    id = Column(Integer, primary_key=True, index=True)
    session_id = Column(String, unique=True, index=True)
    score = Column(Integer, default=0)

    guesses = relationship("Guess", back_populates="session")


class Guess(Base):
    __tablename__ = "guesses"

    id = Column(Integer, primary_key=True, index=True)
    session_id = Column(Integer, ForeignKey("game_sessions.id"))
    word = Column(String)
    position = Column(Integer)  # To maintain linked list order

    session = relationship("GameSession", back_populates="guesses")


class GlobalGuessCounter(Base):
    __tablename__ = "global_guess_counter"

    id = Column(Integer, primary_key=True, index=True)
    word = Column(String, unique=True)
    count = Column(Integer, default=0)
