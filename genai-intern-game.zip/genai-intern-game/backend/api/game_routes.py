from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.ext.asyncio import AsyncSession
from backend.db.database import get_db
from backend.db import models
from backend.core.game_logic import GameLinkedList
from backend.core.ai_client import AIClient
from pydantic import BaseModel
import uuid

router = APIRouter()

# Store active game sessions in memory (simple dictionary for now)
game_sessions = {}

@router.post("/start")
async def start_game():
    session_id = str(uuid.uuid4())
    game_sessions[session_id] = {
        "score": 0,
        "linked_list": GameLinkedList(),
        "last_word": "Rock"  # Starting seed word (example)
    }
    return {"message": "Game started!", "session_id": session_id, "seed_word": "Rock"}

class GuessRequest(BaseModel):
    session_id: str
    guess: str

@router.post("/guess")
async def make_guess(data: GuessRequest, db: AsyncSession = Depends(get_db)):
    session_id = data.session_id
    guess = data.guess
    if session_id not in game_sessions:
        raise HTTPException(status_code=404, detail="Session not found. Start a new game.")

    session_data = game_sessions[session_id]
    linked_list = session_data["linked_list"]
    last_word = session_data["last_word"]

    ai_client = AIClient()
    is_valid = await ai_client.validate_guess(last_word, guess)

    if not is_valid:
        return {"message": f"❌ '{guess}' does NOT beat '{last_word}'. Game Over.", "final_score": session_data["score"]}

    # Check for duplicate guess
    if not linked_list.add_guess(guess):
        return {"message": f"❌ '{guess}' was already guessed. Game Over.", "final_score": session_data["score"]}

    # Update session score
    session_data["score"] += 1
    session_data["last_word"] = guess

    # Update database (game_sessions, guesses, global counter)
    game_session = await db.get(models.GameSession, {"session_id": session_id})
    if not game_session:
        game_session = models.GameSession(session_id=session_id, score=session_data["score"])
        db.add(game_session)
        await db.commit()
        await db.refresh(game_session)

    new_guess = models.Guess(session_id=game_session.id, word=guess, position=session_data["score"])
    db.add(new_guess)

    # Update global guess counter
    result = await db.execute(
        models.GlobalGuessCounter.__table__.select().where(models.GlobalGuessCounter.word == guess)
    )
    counter = result.fetchone()
    if counter:
        await db.execute(
            models.GlobalGuessCounter.__table__.update()
            .where(models.GlobalGuessCounter.word == guess)
            .values(count=counter.count + 1)
        )
    else:
        db.add(models.GlobalGuessCounter(word=guess, count=1))

    await db.commit()

    return {
        "message": f"✅ Nice! '{guess}' beats '{last_word}'.",
        "score": session_data["score"],
        "last_five_guesses": linked_list.get_last_five_guesses()
    }

@router.get("/history")
async def guess_history(session_id: str):
    if session_id not in game_sessions:
        raise HTTPException(status_code=404, detail="Session not found.")
    
    linked_list = game_sessions[session_id]["linked_list"]
    return {"history": linked_list.get_last_five_guesses()}
